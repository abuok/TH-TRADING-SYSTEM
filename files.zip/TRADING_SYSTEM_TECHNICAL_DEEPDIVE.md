# TH-TRADING-SYSTEM: Technical Deep Dive & Architecture Diagrams

---

## Part 1: Data Flow Architecture

### 1.1 Complete Trade Lifecycle

```
┌─────────────────────────────────────────────────────────────────────┐
│                        MARKET DATA INGESTION                         │
├─────────────────────────────────────────────────────────────────────┤
│ Ingestion Service (Port 8001)                                       │
│ ├─ Price Feed: Live OHLCV candles (1H, 4H, Daily)                  │
│ ├─ Economic Calendar: News events + impact levels                  │
│ ├─ Proxy Data: Volatility, correlation matrices                    │
│ └─ Output: MarketContextPacket (market state snapshot)             │
└──────────────────────────┬──────────────────────────────────────────┘
                           │ MarketContextPacket
                           ▼
┌─────────────────────────────────────────────────────────────────────┐
│                      TECHNICAL ANALYSIS                              │
├─────────────────────────────────────────────────────────────────────┤
│ Technical Service (Port 8002)                                       │
│ ├─ PHXDetector: State machine (SETUP→BIAS→PULLBACK→BREAKOUT)       │
│ ├─ Candle Analysis: High-Low tracking, trend detection             │
│ ├─ Pattern Recognition: Specific candlestick patterns              │
│ └─ Output: TechnicalSetupPacket (entry, SL, TP, bias)             │
└──────────────────────────┬──────────────────────────────────────────┘
                           │ TechnicalSetupPacket
                           ▼
┌─────────────────────────────────────────────────────────────────────┐
│                        RISK APPROVAL                                 │
├─────────────────────────────────────────────────────────────────────┤
│ Risk Service (Port 8003)                                            │
│ ├─ 1. Context Staleness: Market data <5 min old? ✓                │
│ ├─ 2. RR Ratio: Risk/Reward ≥ 2.0? ✓                             │
│ ├─ 3. Daily Loss: Current loss < $30? ✓                           │
│ ├─ 4. Consecutive Losses: < 3 losses? ✓                           │
│ ├─ 5. No-Trade Windows: Not during news? ✓                        │
│ ├─ 6. Pair-Specific: Policy matches pair? ✓                       │
│ └─ Output: RiskApprovalPacket (BLOCK/ALLOW + reasons)             │
└──────────────────────────┬──────────────────────────────────────────┘
                           │ RiskApprovalPacket (BLOCK/ALLOW)
                           ▼
                    DECISION POINT
                    │
            ┌───────┴───────┐
            │               │
          BLOCK             ALLOW
            │               │
            ▼               ▼
        Reject          ┌─────────────────────────────────────────────┐
        Ticket          │       TICKET ORCHESTRATION                  │
                        ├─────────────────────────────────────────────┤
                        │ Orchestration Service (Port 8007)           │
                        │ ├─ Generate OrderTicket                    │
                        │ ├─ Validate lot sizing                     │
                        │ ├─ Add to queue                            │
                        │ └─ Output: OrderTicket (ready for review)  │
                        └────────────────┬────────────────────────────┘
                                         │ OrderTicket
                                         ▼
                        ┌─────────────────────────────────────────────┐
                        │       HUMAN REVIEW (DASHBOARD)              │
                        ├─────────────────────────────────────────────┤
                        │ Dashboard (Port 8005)                       │
                        │ ├─ Display pending tickets                 │
                        │ ├─ Show all decision logic                 │
                        │ ├─ Human can APPROVE or REJECT            │
                        │ └─ Output: Updated OrderTicket state      │
                        └────────────────┬────────────────────────────┘
                                         │ Approved Ticket
                                         ▼
                        ┌─────────────────────────────────────────────┐
                        │    EXECUTION (MT5 BRIDGE)                   │
                        ├─────────────────────────────────────────────┤
                        │ MT5 Expert Advisor                          │
                        │ ├─ Receive order parameters                │
                        │ ├─ Place market order                      │
                        │ ├─ Manage position (SL/TP)                │
                        │ └─ Stream live trade data back             │
                        └────────────────┬────────────────────────────┘
                                         │ Live Trade Data
                                         ▼
                        ┌─────────────────────────────────────────────┐
                        │      JOURNALING & OUTCOMES                  │
                        ├─────────────────────────────────────────────┤
                        │ Journal Service (Port 8006)                 │
                        │ ├─ Record trade entry (actual price/time)  │
                        │ ├─ Track trade progression                 │
                        │ ├─ Record exit (profit/loss)              │
                        │ ├─ Calculate metrics (duration, slippage)  │
                        │ └─ Feedback loop to Research               │
                        └────────────────┬────────────────────────────┘
                                         │
                        ┌────────────────┴────────────────┐
                        ▼                                 ▼
                    Daily Report                    Backtesting
                    (dashboard)                      (research)
```

### 1.2 Packet Data Model (Type Contracts)

```python
# Input Packet
class MarketContextPacket(BaseModel):
    timestamp: datetime                    # When data was collected
    pair: str                             # "EURUSD", "XAUUSD", etc.
    current_price: float
    bid: float
    ask: float
    volatility: float                     # ATR or StDev
    has_major_news: bool                  # Next 4 hours
    news_events: List[NewsEvent]
    no_trade_windows: List[tuple]         # [(start, end), ...]
    market_regime: str                    # "trending", "ranging"

# Technical Analysis Output
class TechnicalSetupPacket(BaseModel):
    id: str                               # UUID for tracking
    pair: str
    entry_price: float
    stop_loss: float
    take_profit: float
    bias: Literal["LONG", "SHORT"]
    confidence: float                     # 0.0-1.0
    reasoning: str                        # Why PHX triggered
    timeframe: str                        # "1H", "4H", "D"
    created_at: datetime

# Risk Approval Output
class RiskApprovalPacket(BaseModel):
    id: str
    setup_id: str                         # References TechnicalSetupPacket.id
    is_approved: bool                     # True = ALLOW, False = BLOCK
    status: Literal["APPROVED", "BLOCKED"]
    reasons: List[str]                    # Why approved/blocked
    rr_ratio: float
    applied_policy: str                   # "default", "risk_off", etc.
    evaluated_at: datetime
```

---

## Part 2: Service Communication Map

### 2.1 Inter-Service API Calls

```
┌─────────────┐
│ Ingestion   │ Publishes: MarketContextPacket
│ Service     │ → POST /orchestration/briefing (every hour)
│ (8001)      │
└─────────────┘
        │
        ▼
┌─────────────┐
│ Technical   │ Consumes: MarketContextPacket
│ Service     │ Publishes: TechnicalSetupPacket
│ (8002)      │ → POST /orchestration/tickets (when signal)
└─────────────┘
        │
        ▼
┌─────────────┐
│ Risk        │ Consumes: TechnicalSetupPacket + MarketContextPacket
│ Service     │ Publishes: RiskApprovalPacket
│ (8003)      │ → POST /orchestration/approvals
└─────────────┘
        │
        ▼
┌─────────────┐
│ Orchestration│ Consumes: All above
│ Service     │ Publishes: OrderTicket
│ (8007)      │ Stores: Database
└─────────────┘
        │
        ▼
┌─────────────┐
│ Dashboard   │ Queries: Database
│ Service     │ Updates: OrderTicket state
│ (8005)      │ (human approval)
└─────────────┘
        │
        ▼
┌─────────────┐
│ MT5 Bridge  │ Executes: OrderTicket
│             │ Returns: Live trade data
│             │ → POST /journal/trades
└─────────────┘
        │
        ▼
┌─────────────┐
│ Journal     │ Records: Trade execution
│ Service     │ Outcomes: P&L, duration
│ (8006)      │ → POST /research/outcomes
└─────────────┘
        │
        ▼
┌─────────────┐
│ Research    │ Backtests: Strategies
│ Service     │ Calibrates: Models
│ (8004)      │ Reports: Performance metrics
└─────────────┘
```

---

## Part 3: Database Schema

### 3.1 Core Tables & Relationships

```
┌─────────────┐
│   runs      │ (Backtesting runs)
├─────────────┤
│ id (PK)     │
│ run_id (U)  │
│ started_at  │
│ status      │
└────────┬────┘
         │ 1:N
         │
         ▼
┌──────────────────────┐
│   packets            │ (All data packets)
├──────────────────────┤
│ id (PK)              │
│ run_id (FK → runs)   │
│ packet_type (I)      │ MarketContextPacket, etc.
│ schema_version       │
│ data (JSON)          │
│ created_at (I)       │
└──────────────────────┘

┌──────────────────────┐
│ order_tickets        │ (Trade plans)
├──────────────────────┤
│ id (PK)              │
│ ticket_id (U, I)     │
│ setup_packet_id (FK) │
│ pair                 │
│ entry_price          │
│ stop_loss            │
│ take_profit          │
│ state (I)            │ CREATED, PENDING, APPROVED, EXECUTED
│ created_at           │
│ executed_at          │
│ approved_by          │
└──────────────────────┘
         │ 1:N
         │
         ▼
┌──────────────────────┐
│ trade_outcomes       │ (Live trade results)
├──────────────────────┤
│ id (PK)              │
│ ticket_id (FK)       │
│ actual_entry         │
│ actual_exit          │
│ actual_sl_hit        │
│ profit_loss          │
│ duration             │
│ slippage             │
│ closed_at            │
└──────────────────────┘

┌──────────────────────┐
│ kill_switches        │ (Safety controls)
├──────────────────────┤
│ id (PK)              │
│ switch_type (I)      │ HALT_ALL, HALT_PAIR, etc.
│ target               │ pair name or service name
│ is_active            │
│ created_at           │
└──────────────────────┘

┌──────────────────────┐
│ incident_logs        │ (Event/error tracking)
├──────────────────────┤
│ id (PK)              │
│ severity (I)         │ INFO, WARNING, ERROR, CRITICAL
│ component (I)        │ which service
│ message              │
│ context (JSON)       │ additional data
│ created_at           │
└──────────────────────┘

Legend:
(PK) = Primary Key
(FK) = Foreign Key
(U)  = Unique constraint
(I)  = Indexed column
```

---

## Part 4: Risk Engine - Multi-Layer Validation

### 4.1 Decision Tree

```
OrderTicket received?
│
├─ YES
│  │
│  ▼
│  Context Age Check
│  (market data < 5 min old?)
│  │
│  ├─ STALE (> 5 min)
│  │  └─ BLOCK ❌ "Market data stale"
│  │
│  └─ FRESH
│     │
│     ▼
│     RR Ratio Check
│     (Risk/Reward ≥ 2.0?)
│     │
│     ├─ LOW RR (< 2.0)
│     │  └─ BLOCK ❌ "RR ratio {x} below 2.0"
│     │
│     └─ GOOD RR
│        │
│        ▼
│        Daily Loss Check
│        (today's loss < limit?)
│        │
│        ├─ EXCEEDED
│        │  └─ BLOCK ❌ "Daily loss limit reached"
│        │
│        └─ OK
│           │
│           ▼
│           Consecutive Loss Check
│           (recent losses < 3?)
│           │
│           ├─ TOO MANY
│           │  └─ BLOCK ❌ "Too many consecutive losses"
│           │
│           └─ OK
│              │
│              ▼
│              No-Trade Window Check
│              (not during news event?)
│              │
│              ├─ IN WINDOW
│              │  └─ BLOCK ❌ "Major event in next 4h"
│              │
│              └─ SAFE
│                 │
│                 ▼
│                 Pair Guardrail Check
│                 (policy allows pair?)
│                 │
│                 ├─ PAIR BANNED
│                 │  └─ BLOCK ❌ "Pair not allowed under current policy"
│                 │
│                 └─ ALLOWED
│                    │
│                    ▼
│                    ✅ APPROVE
│                    Order can proceed to execution
│
└─ NO
   └─ ERROR "No order ticket found"

Design Principle: FAIL-SAFE (default to BLOCK unless all checks pass)
```

### 4.2 Account State Tracking

```python
class AccountState:
    """Tracks cumulative trading metrics"""
    
    daily_loss: float = 0.0              # $USD loss today
    consecutive_losses: int = 0           # How many losing trades in a row
    largest_loss: float = -9999.0         # Worst single trade loss
    largest_win: float = 9999.0           # Best single trade profit
    total_trades_today: int = 0
    winning_trades: int = 0
    losing_trades: int = 0
    
    def update_from_outcome(self, outcome: TradeOutcome):
        """Called when trade closes"""
        if outcome.profit_loss < 0:
            self.daily_loss += abs(outcome.profit_loss)
            self.consecutive_losses += 1
            self.losing_trades += 1
        else:
            self.consecutive_losses = 0  # Reset streak on win
            self.winning_trades += 1
        
        self.total_trades_today += 1
        self.largest_loss = min(self.largest_loss, outcome.profit_loss)
        self.largest_win = max(self.largest_win, outcome.profit_loss)
        
        # Use this state for next risk check
        return self
```

---

## Part 5: Configuration System

### 5.1 Policy Routing

```yaml
# config/policies/policy_default.yaml
name: "Default Trading Policy"
version: "1.0.0"

conditions:
  pairs_allowed: ["EURUSD", "GBPUSD", "XAUUSD"]  # Whitelist
  pairs_banned: []
  
  max_daily_loss: 30.0                # Stop trading at -$30
  max_total_loss: 100.0               # Absolute limit
  max_consecutive_losses: 3           # Pause after 3 losses
  
  min_rr_threshold: 2.0               # Risk/Reward
  min_confidence: 0.65                # PHX detector
  
  max_lot_size: 0.1                   # Contract limit
  account_balance: 1000.0             # For position sizing
  
  no_trade_hours: [[14, 16]]          # 14:00-16:00 UTC
  no_trade_before_events: 30          # Minutes before news

---

# config/policies/policy_risk_off.yaml
name: "Risk Off (Drawdown Protection)"
version: "1.0.0"

conditions:
  pairs_allowed: ["EURUSD"]           # Fewer pairs
  
  max_daily_loss: 10.0                # Tighter limit
  max_total_loss: 25.0
  max_consecutive_losses: 1           # Stop after 1 loss
  
  min_rr_threshold: 3.0               # Higher bar
  min_confidence: 0.80
  
  max_lot_size: 0.01                  # 1/10th normal size
  
  no_trade_hours: [[13, 17]]          # More restrictions
  no_trade_before_events: 60
```

### 5.2 Environment Configuration

```bash
# .env (Development)
ENVIRONMENT=development
DEBUG=True

POSTGRES_USER=postgres
POSTGRES_PASSWORD=postgres              # OK for dev
POSTGRES_DB=trading_journal
POSTGRES_HOST=postgres:5432

REDIS_HOST=redis:6379
REDIS_PASSWORD=redis                    # OK for dev

API_SECRET_KEY=dev-secret-key-only     # OK for dev

# Alignment (news events)
ALIGNMENT_NEWS_WINDOW=[-15, 45]         # 15 min before, 45 min after news
ALIGNMENT_VOLATILITY_THRESHOLD=2.0

# Risk thresholds
MAX_DAILY_LOSS=30.0
MAX_CONSECUTIVE_LOSSES=3

---

# .env.prod (Production)
ENVIRONMENT=production
DEBUG=False

POSTGRES_USER=prod_user
POSTGRES_PASSWORD=${VAULT_POSTGRES_PASSWORD}  # From Vault
POSTGRES_DB=trading_prod
POSTGRES_HOST=db.internal:5432

REDIS_HOST=cache.internal:6379
REDIS_PASSWORD=${VAULT_REDIS_PASSWORD}        # From Vault

API_SECRET_KEY=${VAULT_API_SECRET}            # From Vault

ALIGNMENT_NEWS_WINDOW=[-30, 60]              # More conservative
ALIGNMENT_VOLATILITY_THRESHOLD=1.5

MAX_DAILY_LOSS=50.0
MAX_CONSECUTIVE_LOSSES=2
```

---

## Part 6: Testing Strategy

### 6.1 Test Pyramid

```
        /\
       /  \
      /    \  E2E Integration Tests (3)
     /      \ test_mission_*.py
    /────────\────────────
   /          \
  /            \ Service Integration Tests (10)
 /              \ services/*/tests/
/────────────────\
   Unit Tests
  (24 files)
  Per-module
  
Total: 37 test files
Coverage: ~70% (increasing with each PR)
```

### 6.2 Test Categories

**Unit Tests (24 files):**
```python
# Test individual functions in isolation
def test_phx_detector_setup_state():
    detector = PHXDetector()
    candles = [...]
    state = detector.process(candles)
    assert state == PHXStage.SETUP

def test_risk_calculation_rr_ratio():
    engine = RiskEngine(config)
    setup = TechnicalSetupPacket(...)
    rr = engine.calculate_rr(setup)
    assert rr >= 2.0
```

**Service Integration Tests (10 files):**
```python
# Test services working together
async def test_orchestration_ticket_generation():
    """Given a valid technical setup and approval, ticket should be created"""
    setup = TechnicalSetupPacket(...)
    approval = RiskApprovalPacket(is_approved=True, ...)
    
    ticket = await orchestration.create_ticket(setup, approval)
    assert ticket.state == TicketState.APPROVED
    assert ticket.id in database
```

**E2E Tests (3 files):**
```python
# Test complete workflow
def test_mission_a_full_workflow():
    """
    Given: Clean database, live market data
    When: System processes new candle
    Then: Valid setup generates ticket
    And: Ticket passes all risk checks
    And: Ticket appears in dashboard queue
    """
    # Run full pipeline
    # Verify outputs at each stage
```

---

## Part 7: Deployment Topology

### 7.1 Development Environment

```
┌─────────────────────────────────────────┐
│         Developer's Machine             │
├─────────────────────────────────────────┤
│ Docker Desktop (with compose)           │
│                                         │
│ ┌──────────────────────────────────┐   │
│ │ trading-network (bridge)         │   │
│ │                                  │   │
│ │ ┌─ postgres (port 5432)         │   │
│ │ │                                │   │
│ │ ├─ redis (port 6379)            │   │
│ │ │                                │   │
│ │ ├─ ingestion (8001)             │   │
│ │ ├─ technical (8002)             │   │
│ │ ├─ risk (8003)                  │   │
│ │ ├─ research (8004)              │   │
│ │ ├─ dashboard (8005) ← Browser   │   │
│ │ ├─ journal (8006)               │   │
│ │ └─ orchestration (8007)         │   │
│ │                                  │   │
│ └──────────────────────────────────┘   │
│ Volume mounts for hot reload            │
└─────────────────────────────────────────┘
```

### 7.2 Production Environment (AWS Example)

```
┌─────────────────────────────────────────────────────────────┐
│                     AWS Account                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌────────────────────────────────────────────────┐        │
│  │ VPC (trading-vpc)                              │        │
│  │                                                │        │
│  │  ┌──────────────────────────────────────┐     │        │
│  │  │ ECS Cluster (docker)                 │     │        │
│  │  │                                      │     │        │
│  │  │ ┌─ ingestion (3 tasks) ─────┐       │     │        │
│  │  │ ├─ technical (3 tasks) ─────┤ ALB  │     │        │
│  │  │ ├─ risk (2 tasks) ──────────┼──────┼─────┼─ Port 443
│  │  │ ├─ research (1 task) ───────┤      │     │        │
│  │  │ ├─ journal (2 tasks) ───────┤      │     │        │
│  │  │ ├─ orchestration (2 tasks) ─┘      │     │        │
│  │  │ └─ dashboard (2 tasks)             │     │        │
│  │  └──────────────────────────────────────┘     │        │
│  │                                                │        │
│  │  ┌──────────────────────────────────────┐     │        │
│  │  │ RDS (PostgreSQL Multi-AZ)            │     │        │
│  │  │ Backup: Daily snapshots              │     │        │
│  │  └──────────────────────────────────────┘     │        │
│  │                                                │        │
│  │  ┌──────────────────────────────────────┐     │        │
│  │  │ ElastiCache (Redis Cluster)          │     │        │
│  │  │ Multi-AZ failover                    │     │        │
│  │  └──────────────────────────────────────┘     │        │
│  │                                                │        │
│  │  ┌──────────────────────────────────────┐     │        │
│  │  │ Secrets Manager                      │     │        │
│  │  │ - DB credentials                     │     │        │
│  │  │ - API keys                           │     │        │
│  │  │ - MT5 bridge secrets                 │     │        │
│  │  └──────────────────────────────────────┘     │        │
│  │                                                │        │
│  └────────────────────────────────────────────────┘        │
│                                                             │
│  ┌────────────────────────────────────────────────┐        │
│  │ CloudWatch (Monitoring)                        │        │
│  │ - Container logs                              │        │
│  │ - Performance metrics                         │        │
│  │ - Alarms for failures                         │        │
│  │ → SNS → Email/Slack                           │        │
│  └────────────────────────────────────────────────┘        │
│                                                             │
└─────────────────────────────────────────────────────────────┘

External:
- MT5 Terminal (live trading)
- Email/Slack (alerts)
- GitHub Actions (CI/CD)
```

---

## Part 8: Performance Considerations

### 8.1 Latency Budget

```
User Action                     Target Latency    Current
─────────────────────────────────────────────────────────
1. Data ingestion (hourly)       60s              30s ✅
2. Technical analysis            5s               2s  ✅
3. Risk approval                 2s               1s  ✅
4. Ticket creation               1s               0.5s ✅
5. Dashboard refresh             500ms            100ms ✅
6. MT5 order placement           2s               1.5s ✅
────────────────────────────────────────────────────────
Total P&P Cycle                 70s              35s ✅

Note: All within acceptable range for intraday trading.
Bottleneck: Database queries during market hours.
Solution: Connection pooling + read replicas.
```

### 8.2 Database Query Analysis

**Hot Queries:**
```sql
-- Most frequent (1000+ times/day)
SELECT * FROM order_tickets 
WHERE state = 'PENDING_REVIEW' 
ORDER BY created_at DESC;
-- Index: (state, created_at)

-- Second most frequent (500+ times/day)
SELECT * FROM packets 
WHERE packet_type = 'MarketContextPacket' 
  AND created_at > NOW() - INTERVAL '1 hour'
-- Index: (packet_type, created_at)

-- Slow query (kill switches)
SELECT * FROM kill_switches 
WHERE is_active = 1;
-- Index: (is_active)
```

**Optimization Opportunities:**
1. Add connection pooling (PgBouncer, sqlalchemy pool)
2. Add read-only replica for dashboard queries
3. Archive old packets to separate table (>30 days)
4. Add caching layer (Redis) for frequently-read packets

---

## Part 9: Error Handling Patterns

### 9.1 Current Pattern (Good)

```python
try:
    approval = risk_service.evaluate(setup, context)
except RiskEvaluationError as e:
    logger.error(f"Risk evaluation failed: {e}")
    # Default to BLOCK
    return RiskApprovalPacket(is_approved=False, reasons=[str(e)])
except Exception as e:
    logger.error(f"Unexpected error: {e}", exc_info=True)
    incident_log.create(severity="CRITICAL", message=str(e))
    return RiskApprovalPacket(is_approved=False, reasons=["System error"])
```

**Strengths:**
- Explicit exception handling
- Logging with context
- Fail-safe behavior (BLOCK on error)

**Improvements:**
```python
# Add structured logging
from structlog import get_logger

logger = get_logger()

try:
    approval = risk_service.evaluate(setup, context)
    logger.info("risk_approved", setup_id=setup.id, approval=approval)
except RiskEvaluationError as e:
    logger.warning(
        "risk_evaluation_failed",
        setup_id=setup.id,
        error_code=e.code,
        error_message=e.message,
        stack_trace=traceback.format_exc()
    )
    # Incident tracking
    incident.record(
        severity="WARNING",
        component="RiskService",
        error_code=e.code,
        context={"setup_id": setup.id}
    )
```

---

## Part 10: Monitoring & Observability

### 10.1 Current Metrics

```python
# Prometheus metrics available
from prometheus_client import Counter, Histogram

tickets_created = Counter('tickets_created_total', 'Total tickets')
tickets_approved = Counter('tickets_approved_total', 'Approved tickets')
tickets_blocked = Counter('tickets_blocked_total', 'Blocked tickets')

approval_latency = Histogram(
    'approval_latency_seconds',
    'Risk approval latency',
    buckets=[0.1, 0.5, 1.0, 2.0]
)
```

### 10.2 Recommended Enhancements

```python
# Add these metrics:
# Service health
service_health = Gauge('service_health', 'Service status', ['service'])

# Database health
db_connection_pool = Gauge('db_connections_active', 'Active DB connections')
db_query_latency = Histogram('db_query_latency_seconds', '...')

# Business metrics
daily_pnl = Gauge('daily_pnl_usd', 'Daily P&L')
win_rate = Gauge('win_rate_percent', 'Trade win rate')
max_drawdown = Gauge('max_drawdown_percent', 'Maximum drawdown')

# System metrics
event_bus_lag = Histogram('event_bus_lag_seconds', 'Message lag')
task_queue_depth = Gauge('task_queue_depth', 'Pending tasks')
```

---

## Part 11: Security Deep Dive

### 11.1 Secret Management Flow

```
┌─────────────────────────────────────────┐
│  Kubernetes/ECS Task Definition         │
│  (or local .env file in dev)            │
├─────────────────────────────────────────┤
│ VAULT_ADDR=https://vault.internal:8200 │
│ VAULT_TOKEN=s.abcd1234...              │
└──────────────┬──────────────────────────┘
               │
               ▼
┌─────────────────────────────────────────┐
│ Application startup                     │
├─────────────────────────────────────────┤
│ from shared.security.secrets_manager    │
│ import SecretsManager                   │
│                                         │
│ sm = SecretsManager(                    │
│     backend="vault",                    │
│     vault_addr=os.getenv("VAULT_ADDR")  │
│ )                                       │
│                                         │
│ db_password = sm.get_secret(            │
│     "database/prod/password"            │
│ )                                       │
│                                         │
│ db = create_engine(                     │
│     f"postgresql://user:{db_password}@  │
│     host/dbname"                        │
│ )                                       │
└─────────────────────────────────────────┘
```

### 11.2 API Authentication Flow

```
Client Request:
  POST /orchestration/tickets
  Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
  Content-Type: application/json

         │
         ▼

FastAPI Dependency:
  def verify_token(
      credentials: HTTPBearer
  ) -> dict:
      try:
          payload = jwt.decode(
              credentials.credentials,
              settings.SECRET_KEY,
              algorithms=["HS256"]
          )
          return payload
      except JWTError:
          raise HTTPException(
              status_code=401,
              detail="Invalid token"
          )

         │
         ▼

Endpoint:
  @app.post("/tickets")
  async def create_ticket(
      ticket: OrderTicketSchema,
      current_user: dict = Depends(verify_token)
  ):
      # Only executed if token is valid
      # current_user contains decoded JWT claims
      ...
```

---

## Part 12: Deployment Checklist

### Pre-Production Verification

```bash
# 1. Security checks
[ ] bandit -r services/ shared/          # Security scanning
[ ] safety check                          # Dependency scanning
[ ] grep -r "password" --include="*.py" . # No hardcoded secrets

# 2. Database
[ ] Run alembic upgrade head              # Latest schema
[ ] Verify backups: Daily snapshots
[ ] Test restore from backup
[ ] Create indexes: (state, created_at), (packet_type, created_at)

# 3. Configuration
[ ] Create .env.prod with real values
[ ] Verify all secrets in Vault
[ ] Test secret retrieval from Vault
[ ] Enable encryption at rest (PostgreSQL)

# 4. Monitoring
[ ] Prometheus scraping working
[ ] Grafana dashboards set up
[ ] Alert rules configured
[ ] Log aggregation (ELK, CloudWatch) working

# 5. Load testing
[ ] Run with 10 concurrent services
[ ] Run with 1000+ pending tickets
[ ] Run with database failover
[ ] Verify auto-recovery

# 6. Kill switches
[ ] Test HALT_ALL (all trades stop)
[ ] Test HALT_PAIR (EURUSD only)
[ ] Test HALT_SERVICE (ingestion only)
[ ] Verify dashboard controls work

# 7. MT5 integration
[ ] Bridge EA compiled and uploaded
[ ] Paper trading verified
[ ] Order placement tested
[ ] Live signal working (first trade)

# 8. Documentation
[ ] Runbook for common incidents
[ ] Escalation procedures
[ ] Rollback procedures
[ ] On-call schedule established
```

---

## Appendix: Code Examples

### A. Risk Engine Decision

```python
class RiskEngine:
    def evaluate(self, setup, context, account_state, db=None):
        reasons = []
        status = "BLOCK"  # Fail-closed
        is_approved = False
        
        # 1. Staleness
        now = datetime.now(timezone.utc)
        age = (now - context.timestamp).total_seconds()
        if age > 300:  # 5 minutes
            reasons.append(f"Context stale ({age}s)")
            status = "BLOCK"
        else:
            # 2. RR Ratio
            rr = abs(setup.take_profit - setup.entry_price) / \
                 abs(setup.entry_price - setup.stop_loss)
            if rr < 2.0:
                reasons.append(f"RR {rr} < 2.0")
            else:
                # 3. Daily Loss
                if account_state.get("daily_loss", 0) >= 30:
                    reasons.append("Daily loss limit hit")
                else:
                    # 4. Consecutive losses
                    if account_state.get("consecutive_losses", 0) >= 3:
                        reasons.append("Too many consecutive losses")
                    else:
                        # All checks passed
                        status = "APPROVED"
                        is_approved = True
        
        return RiskApprovalPacket(
            is_approved=is_approved,
            status=status,
            reasons=reasons if reasons else ["All checks passed"]
        )
```

### B. Policy Router Decision

```python
class PolicyRouter:
    POLICIES = {
        "default": Policy(...),
        "risk_off": Policy(...),
        "best_conditions": Policy(...),
        "event_heavy": Policy(...)
    }
    
    def route(self, context: MarketContextPacket) -> str:
        """Determine which policy to apply"""
        
        # Most conservative: if major news in next 60 min
        if any(e.impact == "HIGH" 
               for e in context.news_events 
               if e.time_until < 3600):
            return "event_heavy"
        
        # Second most conservative: if high volatility
        if context.volatility > 2.0:
            return "risk_off"
        
        # In good conditions
        if context.trend_strength > 0.8 and context.volatility < 1.0:
            return "best_conditions"
        
        # Default
        return "default"
```

### C. PHX Detector State Machine

```python
class PHXDetector:
    def __init__(self):
        self.state = PHXStage.IDLE
        self.high_since_pivot = 0.0
        self.low_since_pivot = float('inf')
    
    def process(self, candle: Candle) -> PHXStage:
        """Process new candle, emit state changes"""
        
        if self.state == PHXStage.IDLE:
            # Waiting for setup: strong thrust
            if candle.close > candle.open * 1.01:  # +1% thrust
                self.high_since_pivot = candle.high
                self.low_since_pivot = candle.low
                self.state = PHXStage.SETUP
                return self.state
        
        elif self.state == PHXStage.SETUP:
            # Update pivot extremes
            self.high_since_pivot = max(self.high_since_pivot, candle.high)
            self.low_since_pivot = min(self.low_since_pivot, candle.low)
            
            # Look for pullback: touch the setup low
            if candle.low <= self.low_since_pivot * 0.98:
                self.state = PHXStage.PULLBACK
        
        elif self.state == PHXStage.PULLBACK:
            # Look for breakout: reclaim the high
            if candle.high > self.high_since_pivot:
                self.state = PHXStage.BREAKOUT
                # Generate signal here
                return self.state
        
        return self.state
```

---

**Document Version:** 2.0  
**Last Updated:** March 26, 2026  
**Author:** Technical Review Assistant
