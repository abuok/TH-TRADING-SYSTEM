# TH Trading System - Action Items & Implementation Guide

**Date:** March 26, 2026  
**Priority:** Organized by impact and effort  
**Review Reference:** TH_TRADING_SYSTEM_DEEP_REVIEW.md

---

## 🚨 CRITICAL PRIORITY (This Week)

### 1. Add Rate Limiting Middleware
**Why:** DDoS vulnerability - services accept unlimited requests  
**Impact:** CRITICAL  
**Effort:** 2 hours  
**Risk if not done:** System can be brought down with excessive requests  

#### Implementation Steps:

```bash
# 1. Install slowapi
pip install slowapi

# 2. Add to requirements.txt
slowapi==0.1.9
```

```python
# 3. shared/middleware/rate_limiting.py
from slowapi import Limiter
from slowapi.util import get_remote_address
from fastapi import FastAPI

limiter = Limiter(key_func=get_remote_address)
limiter.state.redis_url = "redis://localhost"  # Optional: persistent limits

# 4. Update each service main.py
from shared.middleware import limiter

app = FastAPI()
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, rate_limit_handler)

@app.get("/tickets")
@limiter.limit("100/minute")
async def get_tickets():
    return {"tickets": []}

@app.post("/tickets/{id}/execute")
@limiter.limit("30/minute")  # More restrictive for writes
async def execute_ticket(id: int):
    return {"status": "executing"}

@app.get("/health")
# No limit on health checks
async def health():
    return {"status": "healthy"}
```

**Testing:**
```bash
# Should work
curl -i http://localhost:8000/tickets

# Should fail after 100 requests
for i in {1..101}; do curl http://localhost:8000/tickets; done
# Last request returns 429 Too Many Requests
```

**Configuration (config/.env):**
```
RATE_LIMIT_ENABLED=true
RATE_LIMIT_STORAGE=redis  # or memory
RATE_LIMIT_REDIS_URL=redis://localhost:6379
```

---

### 2. Add Token Revocation (JWT Blacklist)
**Why:** Compromised tokens remain valid until expiry  
**Impact:** SECURITY  
**Effort:** 3 hours  
**Risk if not done:** Stolen token could be used for hours/days  

#### Implementation:

```python
# shared/security/token_blacklist.py
import redis
from datetime import datetime, timedelta
import json

class TokenBlacklist:
    def __init__(self, redis_client: redis.Redis):
        self.redis = redis_client
    
    def revoke_token(self, token: str, expiry_seconds: int = 3600):
        """Add token to blacklist"""
        key = f"token:blacklist:{token}"
        self.redis.set(key, json.dumps({
            "revoked_at": datetime.utcnow().isoformat(),
            "reason": "user_logout"
        }), ex=expiry_seconds)
    
    def is_blacklisted(self, token: str) -> bool:
        """Check if token is revoked"""
        return self.redis.exists(f"token:blacklist:{token}")

# shared/security/auth.py (update)
async def verify_api_token(
    request: Request,
    blacklist: TokenBlacklist = Depends(get_blacklist)
) -> Dict:
    token = extract_token_from_header(request)
    
    # Check if blacklisted
    if blacklist.is_blacklisted(token):
        raise HTTPException(status_code=401, detail="Token revoked")
    
    # Verify signature and expiry
    payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
    return payload

# Usage in logout endpoint
@app.post("/auth/logout")
async def logout(
    token_data: Dict = Depends(verify_api_token),
    blacklist: TokenBlacklist = Depends(get_blacklist)
):
    token = extract_token_from_header(request)
    blacklist.revoke_token(token)
    return {"message": "Logged out"}
```

**Database schema (if using PostgreSQL instead of Redis):**
```sql
CREATE TABLE token_blacklist (
    id SERIAL PRIMARY KEY,
    token_hash VARCHAR(255) UNIQUE NOT NULL,
    revoked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NOT NULL,
    reason VARCHAR(100)
);

CREATE INDEX idx_token_blacklist_expires ON token_blacklist(expires_at);
```

---

### 3. Add Correlation IDs for Request Tracing
**Why:** Hard to debug issues across services without request correlation  
**Impact:** HIGH (observability)  
**Effort:** 2 hours  
**Benefit:** Trace single trade execution across all 6 services  

#### Implementation:

```python
# shared/middleware/correlation_id.py
import uuid
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request

class CorrelationIDMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        correlation_id = request.headers.get(
            "X-Correlation-ID",
            str(uuid.uuid4())
        )
        request.state.correlation_id = correlation_id
        
        response = await call_next(request)
        response.headers["X-Correlation-ID"] = correlation_id
        return response

# In each service main.py
from shared.middleware import CorrelationIDMiddleware

app = FastAPI()
app.add_middleware(CorrelationIDMiddleware)

# Usage in handlers
import structlog
logger = structlog.get_logger()

@app.post("/tickets/{id}/execute")
async def execute(id: int, request: Request):
    logger.info("ticket_execution_started",
        correlation_id=request.state.correlation_id,
        ticket_id=id,
        service="orchestration"
    )
    # ... execution logic
    logger.info("ticket_execution_completed",
        correlation_id=request.state.correlation_id,
        ticket_id=id,
        status="success"
    )
```

**Testing:**
```bash
# Initial request
CORR_ID=$(curl -i http://localhost:8000/tickets/123/execute | grep "X-Correlation-ID")

# Verify all logs have same correlation ID
docker-compose logs | grep $CORR_ID
# Should see logs from orchestration, risk, journal, technical services
```

---

## ⚠️ HIGH PRIORITY (Week 1-2)

### 4. Refactor Large Service Files
**Why:** Files >30KB are hard to test, maintain, understand  
**Impact:** MAINTAINABILITY  
**Effort:** 8 hours  
**Files to refactor:**
- `services/orchestration/main.py` (36KB)
- `services/dashboard/main.py` (27KB)

#### Orchestration Service Refactoring:

```
services/orchestration/
├── main.py              # FastAPI app, routes only
├── handlers/
│   ├── briefing.py      # GET /briefing endpoint logic
│   ├── tickets.py       # /tickets endpoints
│   ├── execution.py     # POST /tickets/{id}/execute
│   └── calibration.py   # /calibrate endpoint
├── services/
│   ├── trade_service.py # Trade execution logic
│   ├── briefing_service.py  # Briefing generation
│   └── validation_service.py # Trade validation
└── models.py            # Request/response models
```

**Example refactoring - Before:**

```python
# services/orchestration/main.py (36KB monster file)
@app.get("/briefing")
async def get_briefing(db: Session = Depends(get_db), request: Request = None):
    # 200+ lines of briefing logic
    # Intermingled with DB queries, business logic, formatting
    pass

@app.post("/tickets/{id}/execute")
async def execute_ticket(id: int, db: Session = Depends(get_db)):
    # 300+ lines of execution logic
    # Risk checks, position updates, journal entries
    pass
```

**After (Refactored):**

```python
# services/orchestration/main.py (only routes)
from handlers import briefing_handler, ticket_handler

@app.get("/briefing")
async def get_briefing(request: Request = Request):
    return await briefing_handler.get_briefing(request)

@app.post("/tickets/{id}/execute")
async def execute_ticket(id: int, request: Request):
    return await ticket_handler.execute(id, request)

# services/orchestration/handlers/briefing.py
async def get_briefing(request: Request) -> Dict:
    """Get trading briefing"""
    async with get_db() as db:
        briefings = await BriefingService.generate(db)
        return {"briefings": briefings}

# services/orchestration/services/briefing_service.py
class BriefingService:
    @staticmethod
    async def generate(db: Session) -> List[Briefing]:
        """Generate daily briefings"""
        # Pure business logic here
        pass
```

**Benefits:**
- Each file <200 lines (easier to test)
- Clear responsibility boundaries
- Reusable services across endpoints
- Easier to find code (clear structure)

---

### 5. Add Pagination to List Endpoints
**Why:** Loading 10,000+ items into memory is slow/inefficient  
**Impact:** PERFORMANCE  
**Effort:** 4 hours  
**Endpoints to fix:**
- `GET /tickets`
- `GET /briefing`
- `GET /trade-history`
- `GET /incidents`

#### Implementation:

```python
# shared/types/pagination.py
from pydantic import BaseModel, Field
from typing import Generic, TypeVar, List

T = TypeVar('T')

class PaginationParams(BaseModel):
    skip: int = Field(0, ge=0, description="Items to skip")
    limit: int = Field(20, ge=1, le=100, description="Items per page")

class PaginatedResponse(BaseModel, Generic[T]):
    items: List[T]
    total: int
    skip: int
    limit: int
    has_more: bool = False

# Usage in service
from shared.types import PaginationParams, PaginatedResponse
from shared.types.trading import TradeTicket

@app.get("/tickets", response_model=PaginatedResponse[TradeTicket])
async def get_tickets(
    params: PaginationParams = Depends(),
    db: Session = Depends(get_db)
):
    # Count total
    total = db.query(Ticket).count()
    
    # Get page
    items = db.query(Ticket)\
        .offset(params.skip)\
        .limit(params.limit)\
        .all()
    
    return PaginatedResponse(
        items=items,
        total=total,
        skip=params.skip,
        limit=params.limit,
        has_more=(params.skip + params.limit) < total
    )
```

**Frontend usage:**
```javascript
// Client-side pagination
let skip = 0;
const limit = 20;

async function loadMore() {
    const response = await fetch(
        `/api/tickets?skip=${skip}&limit=${limit}`
    );
    const data = await response.json();
    
    displayTickets(data.items);
    skip += limit;
    
    if (!data.has_more) {
        disableLazyLoadButton();
    }
}
```

---

### 6. Query Optimization - Fix N+1 Problems
**Why:** Loading tickets loads 1 trade per query = 101 queries!  
**Impact:** PERFORMANCE  
**Effort:** 3 hours  
**Tools:** SQLAlchemy eager loading, database indexing  

#### Identify N+1 Problems:

```python
# ❌ BEFORE (N+1 query problem)
tickets = db.query(Ticket).all()  # 1 query
for ticket in tickets:
    print(ticket.trade.entry_price)  # 100 more queries!
    print(ticket.risk_checks)         # 100 more queries!
# Total: 201 queries!

# ✅ AFTER (Eager loading)
tickets = db.query(Ticket).options(
    selectinload(Ticket.trade),
    selectinload(Ticket.risk_checks)
).all()  # 3 queries total!
for ticket in tickets:
    print(ticket.trade.entry_price)  # No additional queries
    print(ticket.risk_checks)         # No additional queries
```

**Implement in orchestration service:**

```python
# shared/logic/db_optimization.py
from sqlalchemy.orm import selectinload, joinedload

class QueryOptimizer:
    @staticmethod
    def optimize_ticket_queries(query):
        """Apply all eager loading for Ticket queries"""
        return query.options(
            selectinload(Ticket.trade),
            selectinload(Ticket.risk_checks),
            selectinload(Ticket.journal_entries),
            joinedload(Ticket.created_by)
        )

# Usage
@app.get("/tickets")
async def get_tickets(db: Session = Depends(get_db)):
    query = db.query(Ticket)
    query = QueryOptimizer.optimize_ticket_queries(query)
    tickets = query.offset(skip).limit(limit).all()
    return tickets
```

**Add database indexes:**

```python
# In SQLAlchemy models
from sqlalchemy import Index

class Ticket(Base):
    __tablename__ = "tickets"
    
    id = Column(Integer, primary_key=True)
    status = Column(String, index=True)  # ✅ Add index
    created_at = Column(DateTime, index=True)  # ✅ Add index
    trade_id = Column(Integer, ForeignKey("trades.id"), index=True)  # ✅ FK index
    
    # Composite index for common queries
    __table_args__ = (
        Index('idx_status_created_at', 'status', 'created_at'),
    )

# Migration
# alembic revision --autogenerate -m "Add indexes to tickets table"
# alembic upgrade head
```

---

## 📊 MEDIUM PRIORITY (Week 2-3)

### 7. Setup Monitoring Dashboard (Prometheus + Grafana)
**Why:** Can't operate what you can't measure  
**Impact:** OBSERVABILITY  
**Effort:** 6 hours  
**Tools:** Prometheus (metrics), Grafana (visualization)  

#### Step 1: Add Prometheus metrics to services

```python
# shared/metrics/prometheus.py
from prometheus_client import Counter, Histogram, Gauge
import time

# Define metrics
trade_execution_total = Counter(
    'trade_execution_total',
    'Total trade executions',
    ['status']  # success, failed
)

trade_execution_duration = Histogram(
    'trade_execution_duration_seconds',
    'Trade execution duration'
)

active_trades = Gauge(
    'active_trades',
    'Number of active trades'
)

# Usage in handlers
@app.post("/tickets/{id}/execute")
async def execute_ticket(id: int):
    with trade_execution_duration.time():
        try:
            # ... execution logic
            trade_execution_total.labels(status='success').inc()
        except Exception as e:
            trade_execution_total.labels(status='failed').inc()
            raise

# Expose metrics endpoint
from prometheus_client import generate_latest

@app.get("/metrics", include_in_schema=False)
async def metrics():
    return Response(
        generate_latest(),
        media_type="text/plain"
    )
```

#### Step 2: Docker Compose with Prometheus & Grafana

```yaml
# docker-compose.yml addition
prometheus:
  image: prom/prometheus:latest
  volumes:
    - ./config/prometheus.yml:/etc/prometheus/prometheus.yml
  ports:
    - "9090:9090"
  command:
    - '--config.file=/etc/prometheus/prometheus.yml'

grafana:
  image: grafana/grafana:latest
  ports:
    - "3000:3000"
  environment:
    GF_SECURITY_ADMIN_PASSWORD: admin
  volumes:
    - grafana_storage:/var/lib/grafana
```

**Prometheus config:**

```yaml
# config/prometheus.yml
global:
  scrape_interval: 15s
  evaluation_interval: 15s

scrape_configs:
  - job_name: 'orchestration'
    static_configs:
      - targets: ['orchestration:8000']
    metrics_path: '/metrics'
  
  - job_name: 'risk'
    static_configs:
      - targets: ['risk:8003']
    metrics_path: '/metrics'
```

**Grafana dashboards (JSON):**

```json
{
  "dashboard": {
    "title": "Trading System Health",
    "panels": [
      {
        "title": "Trade Execution Success Rate",
        "targets": [
          {
            "expr": "rate(trade_execution_total{status='success'}[5m])"
          }
        ]
      },
      {
        "title": "Trade Execution Duration (p95)",
        "targets": [
          {
            "expr": "histogram_quantile(0.95, trade_execution_duration_seconds)"
          }
        ]
      },
      {
        "title": "Active Trades",
        "targets": [
          {
            "expr": "active_trades"
          }
        ]
      }
    ]
  }
}
```

#### Step 3: Alerting rules

```yaml
# config/prometheus/alerts.yml
groups:
  - name: trading
    rules:
      - alert: HighTradeFailureRate
        expr: |
          rate(trade_execution_total{status='failed'}[5m]) > 0.1
        for: 5m
        annotations:
          summary: "High trade failure rate"
      
      - alert: SlowTradeExecution
        expr: |
          histogram_quantile(0.95, trade_execution_duration_seconds) > 5
        for: 10m
        annotations:
          summary: "Trade execution slow (>5s)"
```

---

### 8. Implement OpenTelemetry for Distributed Tracing
**Why:** Debug issues across microservices  
**Impact:** OBSERVABILITY  
**Effort:** 5 hours  
**Tools:** OpenTelemetry + Jaeger  

```python
# shared/tracing/setup.py
from opentelemetry import trace, metrics
from opentelemetry.exporter.jaeger.thrift import JaegerExporter
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
from opentelemetry.instrumentation.sqlalchemy import SQLAlchemyInstrumentor

def setup_tracing():
    """Initialize OpenTelemetry tracing"""
    jaeger_exporter = JaegerExporter(
        agent_host_name="jaeger",
        agent_port=6831,
    )
    
    trace.set_tracer_provider(TracerProvider())
    trace.get_tracer_provider().add_span_processor(
        BatchSpanProcessor(jaeger_exporter)
    )
    
    # Auto-instrument FastAPI and SQLAlchemy
    FastAPIInstrumentor().instrument_app(app)
    SQLAlchemyInstrumentor().instrument(
        engine=db_engine,
        service=os.getenv("SERVICE_NAME", "unknown")
    )

# In each service main.py
from shared.tracing import setup_tracing

app = FastAPI()
setup_tracing()
```

**Docker Compose:**

```yaml
jaeger:
  image: jaegertracing/all-in-one:latest
  ports:
    - "16686:16686"  # UI
    - "6831:6831/udp"  # Agent
```

**Access traces:**
- Open http://localhost:16686
- Select service (orchestration, risk, etc.)
- View complete traces for single trade execution

---

## 📚 LOW PRIORITY (Week 3+)

### 9. Enable FastAPI OpenAPI Documentation
**Why:** Auto-generated, interactive API docs  
**Impact:** DOCUMENTATION  
**Effort:** 1 hour  

```python
# In each service main.py
from fastapi import FastAPI

app = FastAPI(
    title="Trading System - Orchestration Service",
    description="Master trading orchestration service",
    version="1.0.0",
    docs_url="/docs",  # Swagger UI
    redoc_url="/redoc",  # ReDoc
)

# Endpoint documentation
@app.post("/tickets/{id}/execute", tags=["Execution"])
async def execute_ticket(
    id: int = Path(..., description="Ticket ID to execute"),
    db: Session = Depends(get_db)
) -> Dict:
    """
    Execute a trading ticket.
    
    Validates risk, updates positions, creates journal entry.
    
    Returns:
        - ticket_id: ID of executed ticket
        - status: "executing" | "blocked"
        - reason: Why it was blocked (if applicable)
    """
    ...
```

**Access docs:**
- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

---

### 10. Add End-to-End Tests
**Why:** Verify complete trade execution flow  
**Impact:** RELIABILITY  
**Effort:** 6 hours  

```python
# tests/test_e2e_trade_execution.py
import pytest
from httpx import AsyncClient

@pytest.mark.e2e
async def test_full_trade_lifecycle(client: AsyncClient, db_session: Session):
    """Test: Generate → Review → Execute → Journal → Verify"""
    
    # Step 1: Generate briefing
    response = await client.get("/briefing")
    assert response.status_code == 200
    briefing = response.json()
    
    # Step 2: Get trade tickets
    response = await client.get("/tickets")
    assert response.status_code == 200
    tickets = response.json()["items"]
    assert len(tickets) > 0
    ticket_id = tickets[0]["id"]
    
    # Step 3: Execute ticket
    response = await client.post(f"/tickets/{ticket_id}/execute")
    assert response.status_code == 200
    execution = response.json()
    assert execution["status"] in ["executing", "blocked"]
    
    # Step 4: Verify journal entry
    response = await client.get("/journal/entries")
    assert response.status_code == 200
    entries = response.json()
    assert any(e["ticket_id"] == ticket_id for e in entries)
    
    # Step 5: Verify database state
    db_ticket = db_session.query(Ticket).filter(Ticket.id == ticket_id).first()
    assert db_ticket.status == "executed"
    assert db_ticket.executed_at is not None
```

---

## 📋 TRACKING & VERIFICATION

### Completion Checklist

```
CRITICAL PRIORITY
─────────────────
☐ 1. Add rate limiting
    - [ ] Install slowapi
    - [ ] Add middleware to all services
    - [ ] Configure limits (API endpoint)
    - [ ] Add tests
    - [ ] Deploy to staging

☐ 2. Add token revocation
    - [ ] Implement TokenBlacklist
    - [ ] Update verify_api_token
    - [ ] Add logout endpoint
    - [ ] Test revocation
    - [ ] Deploy

☐ 3. Add correlation IDs
    - [ ] Create CorrelationIDMiddleware
    - [ ] Add to all services
    - [ ] Update logging
    - [ ] Test end-to-end
    - [ ] Deploy

HIGH PRIORITY
─────────────
☐ 4. Refactor large files
    - [ ] Split orchestration/main.py
    - [ ] Split dashboard/main.py
    - [ ] Organize handlers/services
    - [ ] Update imports
    - [ ] Run tests
    - [ ] Code review
    - [ ] Deploy

☐ 5. Add pagination
    - [ ] Create PaginationParams
    - [ ] Update endpoints
    - [ ] Add limit validation
    - [ ] Update frontend
    - [ ] Test
    - [ ] Deploy

☐ 6. Query optimization
    - [ ] Identify N+1 queries
    - [ ] Add eager loading
    - [ ] Add database indexes
    - [ ] Run migrations
    - [ ] Benchmark improvement
    - [ ] Deploy

MEDIUM PRIORITY
───────────────
☐ 7. Monitoring dashboard
    - [ ] Add Prometheus metrics
    - [ ] Create Docker Compose entry
    - [ ] Create Grafana dashboards
    - [ ] Setup alerting
    - [ ] Train team
    - [ ] Deploy

☐ 8. Distributed tracing
    - [ ] Setup OpenTelemetry
    - [ ] Deploy Jaeger
    - [ ] Test traces
    - [ ] Create runbooks
    - [ ] Deploy

LOW PRIORITY
────────────
☐ 9. OpenAPI docs
    - [ ] Add docstrings
    - [ ] Enable /docs
    - [ ] Test endpoints
    - [ ] Deploy

☐ 10. E2E tests
     - [ ] Create test fixtures
     - [ ] Write trade lifecycle test
     - [ ] Add performance checks
     - [ ] Integrate with CI
     - [ ] Deploy
```

---

## 🚀 DEPLOYMENT STRATEGY

### Week 1: Critical Security
```
Mon-Tue: Rate limiting + Token revocation
Wed-Thu: Correlation IDs + Testing
Fri: Code review + Staging deployment
```

### Week 2: Performance
```
Mon-Tue: Large file refactoring
Wed-Thu: Pagination + N+1 optimization
Fri: Load testing + Staging validation
```

### Week 3: Observability
```
Mon-Tue: Prometheus metrics
Wed-Thu: Jaeger distributed tracing
Fri: Dashboard creation + Team training
```

---

## 📞 SUPPORT & QUESTIONS

**For implementation questions:**
1. Refer to code examples in this document
2. Check TH_TRADING_SYSTEM_DEEP_REVIEW.md for context
3. Review GitHub issues/discussions

**Estimated total effort:** 40-50 hours  
**Recommended allocation:** 1-2 engineers, 4-5 weeks  
**Expected benefit:** Enterprise-grade system with full observability  

---

**Document Version:** 1.0  
**Last Updated:** March 26, 2026  
**Status:** Ready for Implementation
